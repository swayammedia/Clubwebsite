
using UnityEngine;

public class endinggame : MonoBehaviour
{
    public void Quit()
    { 
        Application.Quit();
    }

}
